package com.capgemini.capstore.service;

import java.util.List;

import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.Wishlist;

public interface WishlistServiceInterface {


	public Wishlist displayProducts(int customerId);

	public Wishlist addProducts(int customerId, int merchantId, Product product);

	List<Wishlist> deleteProducts(int customerId);

}
